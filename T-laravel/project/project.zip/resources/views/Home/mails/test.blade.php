尊敬的<我的商城>用户：{{$name}}
欢迎使用聚合数据提供的数据服务！
请点击以下的链接验证您的邮箱，验证成功后就可以使用聚合提供的所有服务了。
<a href="http://www.shop.com/Home/Index/activeMember?code={{$code}}">
        http://www.shop.com/Home/Index/activeMember?code={{$code}}
</a>
