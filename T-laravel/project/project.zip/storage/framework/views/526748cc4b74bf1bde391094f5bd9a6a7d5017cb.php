您正在为 "<?php echo e($role_name); ?>" 分配权限....
<script type="text/javascript" src="<?php echo e(asset('Admin/js/jquery.min.js')); ?>"></script>
<style>
    li{
        list-style-type: none;
    }
</style>
<form action="<?php echo e(url('Admin/Role/assignAuthAction')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul>
            <li style="font-weight: bold"><input type="checkbox" name="auth_id[]" value="<?php echo e($v->aid); ?>" class="chk" myid="<?php echo e($v->aid); ?>" pid="<?php echo e($v->pid); ?>" checkSel="sel_<?php echo e($v->pid); ?>" ch="ch_<?php echo e($v->aid); ?>"
                                                 <?php if($v->issel == 1): ?>
                                                 checked
                        <?php endif; ?>
                ><?php echo e($v->auth_name); ?></li>
            <li>

                <ul>
                    <?php $__currentLoopData = $v->son; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><input type="checkbox" name="auth_id[]" value="<?php echo e($v1->aid); ?>" class="chk" myid="<?php echo e($v1->aid); ?>" pid="<?php echo e($v1->pid); ?>"  checkSel="sel_<?php echo e($v1->pid); ?>"
                                   <?php if($v1->issel == 1): ?>
                                   checked
                                    <?php endif; ?>
                            ><?php echo e($v1->auth_name); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

            <li>
        </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <input type="hidden" value="<?php echo e($id); ?>" name="role_id">
    <input type="submit" value="提交">
</form>
<script>
    $('.chk').click(function(){
       var sel = $(this).is(":checked")
        var myid = $(this).attr('myid');
        var pid = $(this).attr('pid');
        if(sel){
           // 它被选中了。。。 获取当前的权限的id,让孩子们全部被选中
            $("input[checkSel='sel_"+myid+"']").prop('checked','checked');
            // 它被选中了。。。。让他的父亲被选中
            $("input[ch='ch_"+pid+"']").prop('checked','checked');
        }else{
            // 如果自己都不选了，让孩子们全部取消
            $("input[checkSel='sel_"+myid+"']").removeAttr('checked');

            // 只要取消掉 就会取消掉 父亲的属性
            // 点击了谁，通过自己，找到自己的兄弟，看看自己的兄弟有没有被选中的
            var flag = true;
            $("input[checksel='sel_"+pid+"']").each(function(){
                if($(this).is(":checked")){
                    flag = false;// 3  2  1 0
                }
            });
            if(flag){
                $("input[ch='ch_"+pid+"']").removeAttr('checked');
            }

        }
    })
</script>
